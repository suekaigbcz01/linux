#include "code.h"
int myfun(int in)
{
	return in+1;
}
