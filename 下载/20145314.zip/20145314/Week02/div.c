#include "head.h"
double div(int a, int b){
	return a/b;
}
