int loop(int x, int n)
{
int result = 1431655765;
int mask;
for(mask = 1 << 31; 
    mask != 0;
    mask = ((unsigned)mask) >> n)
 {
  result ^= (mask & x);
 }
return result;
}
