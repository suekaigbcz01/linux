#include <stdio.h>
#include "code.h"
int main(void)
{
	int i = 1;
	printf("myfun(i) = %d\n",myfun(i));
}
