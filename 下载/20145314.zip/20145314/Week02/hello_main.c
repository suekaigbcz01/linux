#include "hello.h"
void print();
int main(int argc, char **argv)
{
	print();
}

