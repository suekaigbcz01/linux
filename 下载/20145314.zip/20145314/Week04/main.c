int a(int x)
{
return x + 1;
}

int b(int x)
{
return a(x);
}

int main(void)
{
return b(8) + 14;
}
